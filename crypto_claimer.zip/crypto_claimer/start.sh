python3 bot.py +6281335808609 doge
python3 bot.py +6281335808609 zec
python3 bot.py +6281335808609 ltc
python3 bot.py +6281335808609 btc
python3 bot.py +6281335808609 bch
clear
pwd
bash start.sh

#Replace [phone] with your Number Phone
#ext 
   python bot.py +62xxxx doge
