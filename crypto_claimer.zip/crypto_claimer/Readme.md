# 🔥 AUTO CLAIM POPULAR 5 CLICK BOT USING 1 TERMUX SCRIPT
 
**START All Bot Below at Telegram :**
1. **Doge** 📲 [https://t.me/Dogecoin_click_bot ](https://t.me/Dogecoin_click_bot?start=tIh2)   
2. **LTC** 📲 [https://t.me/Litecoin_click_bot](https://t.me/Litecoin_click_bot?start=PE7K)  
3. **ZEC** 📲 [https://t.me/Zcash_click_bot](https://t.me/Zcash_click_bot?start=4CnY)  
4. **BCH** 📲 [https://t.me/BCH_clickbot](https://t.me/BCH_clickbot?start=X6Hp)  
5. **BTC** 📲 [https://t.me/BitcoinClick_bot](https://t.me/BitcoinClick_bot?start=QTPJ)

**TERMINAL/TERMUX :**

> apt update --pkg upgrade  
apt install python git  
git clone https://github.com/XTuyul/5ClickBot1    
cd 5ClickBot1  
pkg install python  
pkg install nano  
pkg install pip  
pip install telethon  
pip install --upgrade pip  
pip install requests  
pip install bs4  
pip install rsa  
pip install pyaes  
pip install async_generator  
pip install colorama  
pkg install requirements.txt  
nano start.sh  

**Execute Code**  
After edit and replace phone number in `start.sh` now you can execute your script in termux terminal with command :  
> bash start.sh

If you want play script with single Bot Coin Title you can just type this command :  
> python bot.py +[phone] [coin] 

**Note :**  
 `[phone]` = Internation Code Phone Number Already Registered on Telegram Above  
 `[coin]` = Coin Title Bot  
 
_Ext_ :  
python bot.py +[Phone] Doge  
Python bot.py +[Phone] LTC  
python bot.py +[Phone] ZEC  
python bot.py +[Phone] BCH  
python bot.py +[Phone] BTC  
